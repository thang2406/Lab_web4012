<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TestController extends Controller
{
    public function check(Request $request)
    {
    	$date=[
    		'username'=>$request->username,
    		'password'=>$request->password,
    	];
    	if(Auth::attempt($date)){
            return view('home');
    	}else{
            return 'Không thành công';
    	}
    }
}
