<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use App\Exception\CustomException;

class ExceptionController extends Controller
{
    public function index(){
    	throw new \App\Exceptions\CustomException('Somthing Went Wrong.');
    	
    }
}
