<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Wellcome Email</title>
</head>
<body>
	<h2>Welcome to the site {{ $user['name'] }}</h2>
	<br>
	Your register email-id is {{ $user['email'] }}
</body>
</html>