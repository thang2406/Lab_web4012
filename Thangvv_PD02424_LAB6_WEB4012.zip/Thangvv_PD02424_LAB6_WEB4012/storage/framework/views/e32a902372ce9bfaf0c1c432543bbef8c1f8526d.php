<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Wellcome Email</title>
</head>
<body>
	<h2>Welcome to the site <?php echo e($user['name']); ?></h2>
	<br>
	Your register email-id is <?php echo e($user['email']); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\WEB4012\Thangvv_PD02424_LAB6_WEB4012\resources\views/email/welcome.blade.php ENDPATH**/ ?>