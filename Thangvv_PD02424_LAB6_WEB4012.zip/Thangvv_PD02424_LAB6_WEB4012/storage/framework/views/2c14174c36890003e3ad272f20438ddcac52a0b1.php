<div>
	Hi, This is : <?php echo e($name); ?>

</div><?php /**PATH C:\xampp\htdocs\WEB4012\Thangvv_PD02424_LAB6_WEB4012\resources\views/name.blade.php ENDPATH**/ ?>